# Curly & Wavy hairstyle assets — cleaned web package

## What is included
- 38 curated image files converted to optimized WebP.
- Consistent, descriptive filenames grouped under `images/curly-wavy/`.
- `images/curly-wavy/manifest.json` maps each image to its original filename and style.
- `curly-wavy-gallery.html` contains responsive gallery cards and a standalone lightbox.
- `curly-wavy-gallery.css` contains the matching responsive styles.

## Duplicate cleanup
The source ZIP contained 40 image files. Two exact duplicate copies were removed:
- `Max_a_Textured_Waves_A._Ha (1).png` (same bytes as `Max_a_Textured_Waves_A._Ha.png`)
- `mai-image-2.6 (t2i)_b_Textured_Waves_A._Ha (2).png` (same bytes as `mai-image-2.6 (t2i)_b_Textured_Waves_A._Ha (3).png`)

The remaining 38 files were retained as distinct references/variants. Similar-looking images were not automatically deleted because they are not byte-identical and may show different model references.

## Add to the website
1. Copy the `images/curly-wavy/` folder into the root of the website repository.
2. Add the CSS from `curly-wavy-gallery.css` to the site's stylesheet, or link it from `index.html`.
3. Insert the contents of `curly-wavy-gallery.html` at the position where the Curly & Wavy category should appear.
4. Ensure the image paths remain `images/curly-wavy/...` relative to `index.html`.
5. Commit and push the updated files to GitHub.

The supplied gallery uses its own `cw-` CSS class names and a namespaced lightbox to reduce conflicts with the existing site. Review integration if the site already has a global modal/lightbox.

## Source coverage note
The ZIP contains references for these identified styles: Curly High Top, Curly Top, Textured Waves, Wavy Side Part, Wavy Quiff, Curly Fade, Curly Undercut, Natural Waves, Medium Curly Hair, Short Curly Crop, Curly Taper, and Curly Fringe. It does not contain clearly identifiable image assets for every item in the full 81–95 list (notably Afro Hairstyle, Twist Hairstyle, and Short Afro). No missing styles were invented.
