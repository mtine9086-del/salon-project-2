# Salon image upload pack

Optimized WebP images selected from `new img 2.zip` for the men's salon catalogue.

## Folders
- `haircuts/` — haircut references
- `beard-styles/` — beard and moustache references
- `image-manifest.csv` — display labels and original filenames

## Upload
1. Open the GitHub repository `mtine9086-del/salon-project-2`.
2. Upload the contents of `haircuts/` and `beard-styles/` into matching folders in the repository (create folders if needed).
3. Keep filenames unchanged.
4. The images will not appear on the website until the site's `index.html`/catalogue data is updated to reference these filenames.

## Excluded during curation
- Both beard/moustache contact-sheet collage files (duplicate copies).
- The hairstyle chart collage and catalogue UI screenshot.
- Exact duplicate portrait files: `pexels-claudio-emanuel-709239809-18935835 (1).jpg` and `pexels-iamluisao-12706272 (5).jpg`.
- A visually repeated quiff portrait (`pexels-barczakshoots-7460149 (1).jpg`) matching the selected Damian Barczak quiff portrait.
- Unrelated fashion/editorial portraits that did not clearly demonstrate a haircut or beard reference.

Note: filenames and labels are suggested catalogue labels based on visual appearance; verify the exact haircut name with a barber before publishing as a technical style name. Source ZIP did not include license records; confirm each image's usage rights before commercial publication.
