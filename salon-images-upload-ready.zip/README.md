# Salon grooming image catalogue — upload-ready

## Review summary
- Source archive: 43 JPEG entries.
- Exact duplicate files detected by SHA-256: 2 duplicate copies removed (source entries 27 duplicates 4; 43 duplicates 41).
- Final unique images: 41.
- Converted to WebP, max 1400 × 1800 px, quality 84, preserving original composition (no face retouching or artificial edits).
- Folder groups: `beard-looks`, `haircut-looks`, `editorial-portraits`.
- Images are named with conservative visual descriptions. These are visual classifications, not guaranteed technical haircut names.

## Quality notes
- Most images are portrait/editorial photos, not clean barber-cut reference shots.
- Strongest haircut-detail references: `hair-15-classic-side-part-undercut`, `hair-16-high-fade-side-part`, `hair-17-short-crop-fade`, and the `hair-11` to `hair-13` set.
- Beard images are primarily style portraits; several are lifestyle/editorial shots with sunglasses, hats, or dramatic lighting. They should not all be presented as precise beard-cut templates.
- Some images are non-Indian / international-looking models. Keep them as inspiration references, not a claim that every photo depicts a local customer.
- Source images were not facially altered. Color grading was not applied; conversion is loss-conscious WebP compression.

## Website integration
Use the `output_file` paths in `image-manifest.json`. Keep image cards linked to the correct original image. Use `loading="lazy"` except the first visible hero image. Avoid stretching; use `object-fit: contain` for full portrait photos and `object-fit: cover` only when a deliberately cropped card is acceptable.
