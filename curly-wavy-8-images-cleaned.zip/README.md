# Curly & Wavy Image Pack — Cleaned

## Contents
- 8 distinct source images, converted to optimized WebP.
- Descriptive filenames in `images/curly-wavy/`.
- `manifest.json` with titles, descriptions and dimensions.
- `curly-wavy-gallery.html`, a standalone responsive gallery with click-to-enlarge.

## Duplicate review
All 8 original files were checked using SHA-256 exact-file hashes. No exact duplicate files were found, so all 8 were retained. Some images show similar hairstyles (for example, Natural Waves and Wavy Side Part), but they are different images/alternate references and were not deleted.

## Suggested integration
Copy the `images/curly-wavy/` folder into the website repository, preserving this path. Then add the cards from `curly-wavy-gallery.html` into the existing hairstyle gallery container. Do not replace the website's existing `index.html` with the standalone preview unless you intend to use it as a separate page.

## Image classification note
Titles are based on visible styling and any legible title text in the supplied images. Treat them as reference labels; confirm with a barber before presenting a technically exact cut name.
