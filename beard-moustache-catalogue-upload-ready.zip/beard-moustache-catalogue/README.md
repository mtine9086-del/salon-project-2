# Beard & Moustache Catalogue — Cleaned Upload Package

## What is included
- 42 selected beard/moustache portrait images.
- Images are converted to optimized WebP (quality 88), RGB, with maximum dimension 1800 px.
- Original visual content is preserved; no AI retouching or face edits were applied.
- `IMAGE_INDEX.csv` maps each output image to its original filename and dimensions.

## Folder structure
- `01_Beard_Portraits/` — beard-focused portraits.
- `02_Traditional_Turban_Beard/` — portraits with traditional turbans and beards.
- `03_Moustache_Focused/` — moustache-focused portraits.

## Important curation notes
- The uploaded ZIP contained 73 image files, including hairstyle reference cards/graphics and beard/moustache portraits.
- Exact duplicate files were detected and consolidated (3 duplicate copies removed).
- Hairstyle reference graphics and portraits that did not clearly show a beard/moustache were not included in this beard-only upload package.
- Categories describe visible presentation only; they do not certify a person's regional identity or a standardized barber style.
- Some source images contain AI-generated models and some are stock photographs. Verify commercial-use rights and any model-release requirements before publishing. The ZIP itself does not prove licensing.
- No face identity matching, hairstyle consistency, or five-angle set is guaranteed.

## Website use
Use the WebP files directly in your project. Keep the filenames stable or update your website's image paths if you rename them.
